const{add, subtract, multiply,divide}=require("./calculator");

test('adds 1+2 to equal 3',()=>{
    expect(add(1,2)).toBe(3)
});

test('throwing exception',()=>{
    expect(()=>add('1','2')).toThrow('Invalid input');
})

test('substract 1-2 to equal -1',()=>{
    expect(subtract(1,2)).toBe(-1)
});

test('throwing exception',()=>{
    expect(()=>subtract('1','2')).toThrow('Invalid input');
})

test('multiply 1*2 to equal 2',()=>{
    expect(multiply(1,2)).toBe(2)
});

test('throwing exception',()=>{
    expect(()=>multiply('1','2')).toThrow('Invalid input');
})

test('divide 4/2 to equal 2',()=>{
    expect(divide(4,2)).toBe(2)
});

test('throwing exception',()=>{
    expect(()=>divide('1','2')).toThrow('Invalid input');
})

test('throwing exception',()=>{
    expect(()=>divide(1,0)).toThrow();
})

